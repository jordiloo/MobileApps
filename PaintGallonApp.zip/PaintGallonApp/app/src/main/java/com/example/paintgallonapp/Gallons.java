package com.example.paintgallonapp;

import androidx.annotation.NonNull;

import java.text.DecimalFormat;

public class Gallons {
    private final int height;
    private final int distance;
    String color;
    //private double cost;

    public Gallons(int height, int distance, String g){
        this.height = height;
        this.distance = distance;
        color = g;
    }

    public double calculateCost(){
        double totalGallons;
        int squareFeet = height * distance;
        totalGallons = (double) squareFeet / 250;
        return totalGallons;
    }



    @NonNull
    @Override
    public String toString(){
        DecimalFormat gallon = new DecimalFormat("###,###.##");
        return "The color you picked is " + color + " and the total number of gallons is " + gallon.format(calculateCost());
    }
}
