package com.example.paintgallonapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Second extends AppCompatActivity {
    int heightNumberInFeet;
    int distanceNumberInFeet;
    String color;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        TextView result = findViewById(R.id.txtTotalGallons);
        Intent intent = getIntent();
        if(intent!=null){
            color = intent.getStringExtra("Color");
            heightNumberInFeet = intent.getIntExtra("HEIGHT", heightNumberInFeet);
            distanceNumberInFeet = intent.getIntExtra("DISTANCE", distanceNumberInFeet);
            Gallons gallon = new Gallons(heightNumberInFeet, distanceNumberInFeet, color);
            result.setText(gallon.toString());

        }
    }
}