package com.example.paintgallonapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

//    double paintPrice = 0.0;
    int heightNumberInFeet;
    int distanceNumberInFeet;
    String color;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText height = findViewById(R.id.txtInputHeight);
        EditText distance = findViewById(R.id.txtInputDistance);
        Spinner chooseAColor = findViewById(R.id.spnColor);
        Button btnPrice = findViewById(R.id.btnCost);

        btnPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(height.getText().toString())){
                    height.setError("enter the height");
                }else{
                    heightNumberInFeet= Integer.parseInt(height.getText().toString());
                    distanceNumberInFeet = Integer.parseInt(distance.getText().toString());
                    color = chooseAColor.getSelectedItem().toString();

                    Intent intent = new Intent(MainActivity.this,Second.class);
                    intent.putExtra("Color",color);
                    intent.putExtra("HEIGHT",heightNumberInFeet);
                    intent.putExtra("DISTANCE", distanceNumberInFeet);
                    startActivity(intent);
                }
                if(TextUtils.isEmpty(distance.getText().toString())){
                    distance.setError("enter the distance around the room");
                }else{
                    heightNumberInFeet= Integer.parseInt(height.getText().toString());
                    distanceNumberInFeet = Integer.parseInt(distance.getText().toString());
                    color = chooseAColor.getSelectedItem().toString();

                    Intent intent = new Intent(MainActivity.this,Second.class);
                    intent.putExtra("Color",color);
                    intent.putExtra("HEIGHT",heightNumberInFeet);
                    intent.putExtra("DISTANCE", distanceNumberInFeet);
                    startActivity(intent);
                }
            }
        });
    }
}